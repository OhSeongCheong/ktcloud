from django.db import models
from django.contrib.auth.models import User

class Bookmark(models.Model):
    title = models.CharField('TITLE', max_length=100, blank=True)
    url = models.URLField('URL', unique=True)
    owner = models.ForeignKey(User, to_field='id', db_column='owner', on_delete=models.CASCADE, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'bookmark'

    def __str__(self):
        return "%s" %(self.title)
