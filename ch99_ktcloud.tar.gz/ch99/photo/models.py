from django.db import models
from django.urls import reverse
from photo.fields import ThumbnailImageField

class Album(models.Model):
    name = models.CharField(max_length=30)
    description = models.CharField('One Line Description', max_length=100, blank=True)
    owner = models.ForeignKey('auth.User', to_field='id', db_column='owner', on_delete=models.CASCADE, verbose_name='owner', blank=True, null=True)
    # auth.User  : 앱명.테이블명

    class Meta:
        managed = False
        ordering = ('name',)
        db_table = 'album'

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('photo:album_detail.html', args=(self.id,))

class Photo(models.Model):
    album = models.ForeignKey(Album, to_field='id', db_column='album', on_delete=models.CASCADE)
    title = models.CharField('Title', max_length=30)
    description = models.TextField('Photo Description', blank=True)
    image = ThumbnailImageField(upload_to='photo/%Y/%m', blank=True, null=True)
    upload_dt = models.DateTimeField('Upload Date', auto_now_add=True)
    owner = models.ForeignKey('auth.User', to_field='id', db_column='owner', on_delete=models.CASCADE, verbose_name='owner', blank=True, null=True)

    class Meta:
        managed = False
        ordering = ('title',)
        db_table = 'photo'

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('photo:photo_detail', args=(self.id,))
