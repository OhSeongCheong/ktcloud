from django.contrib import admin
from blog.models import Post

@admin.register(Post) #admin.site.register(Post, PostAdmin) 과도 동일
class PostAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'slug', 'create_dt', 'modify_dt', 'tag_list')
#   list_display = ('id', 'title', 'slug', 'create_dt', 'modify_dt')
    list_filter = ('modify_dt',)
    search_fields = ('title','content')
    prepopulated_fields = {'slug':('title',)}

    def get_queryset(self, request):
        return super().get_queryset(request).prefetch_related('tags')

    def tag_list(self, obj):
        return ', '.join(o.name for o in obj.tags.all())